﻿{
	"version": 1709169259,
	"fileList": [
		"data.js",
		"c2runtime.js",
		"jquery-3.4.1.min.js",
		"offlineClient.js",
		"images/background-sheet0.png",
		"images/bird-sheet0.png",
		"images/bird-sheet1.png",
		"images/pipa-sheet0.png",
		"images/pipaatas-sheet0.png",
		"images/lantai-sheet0.png",
		"images/bgf-sheet0.png",
		"images/playremovebgpreview-sheet0.png",
		"images/homeremovebgpreview-sheet0.png",
		"icon-16.png",
		"icon-32.png",
		"icon-114.png",
		"icon-128.png",
		"icon-256.png",
		"loading-logo.png"
	]
}